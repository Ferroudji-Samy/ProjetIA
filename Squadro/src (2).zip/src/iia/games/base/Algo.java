package iia.games.base;

public class Algo {

}
